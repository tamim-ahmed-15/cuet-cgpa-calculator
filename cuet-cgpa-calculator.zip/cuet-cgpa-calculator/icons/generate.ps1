Add-Type -AssemblyName System.Drawing

function New-Icon($size, $fontSize, $outputPath) {
    $bmp = New-Object System.Drawing.Bitmap($size, $size)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'
    $g.TextRenderingHint = 'AntiAlias'
    
    $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
        [System.Drawing.Point]::new(0, 0),
        [System.Drawing.Point]::new($size, $size),
        [System.Drawing.Color]::FromArgb(99, 102, 241),
        [System.Drawing.Color]::FromArgb(168, 85, 247)
    )
    $g.FillRectangle($brush, 0, 0, $size, $size)
    
    $font = New-Object System.Drawing.Font('Arial', $fontSize, [System.Drawing.FontStyle]::Bold)
    $sf = New-Object System.Drawing.StringFormat
    $sf.Alignment = 'Center'
    $sf.LineAlignment = 'Center'
    $rect = [System.Drawing.RectangleF]::new(0, 0, $size, $size)
    $g.DrawString('C', $font, [System.Drawing.Brushes]::White, $rect, $sf)
    
    $bmp.Save($outputPath, [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose()
    $bmp.Dispose()
    $font.Dispose()
    $brush.Dispose()
    Write-Host "Created $outputPath"
}

$dir = "g:\cuet-cgpa-calculator\icons"
New-Icon 48 28 "$dir\icon48.png"
New-Icon 128 76 "$dir\icon128.png"
Write-Host "Done!"
