(function () {
  "use strict";

  // ── Grade-point mapping (CUET / Bangladesh standard) ──
  const GRADE_MAP = {
    "A+": 4.0,
    A: 3.75,
    "A-": 3.5,
    "B+": 3.25,
    B: 3.0,
    "B-": 2.75,
    "C+": 2.5,
    C: 2.25,
    D: 2.0,
    F: 0.0,
  };

  //parse every row from the DataTable (all pages)
  function getAllRows() {

    const table = document.querySelector("table.dataTable, table.table");
    if (!table) return [];

    const rows = [];
    const tbody = table.querySelector("tbody");
    if (!tbody) return [];

    tbody.querySelectorAll("tr").forEach((tr) => {
      const cells = tr.querySelectorAll("td");
      if (cells.length < 6) return;

      const courseCode = cells[0].textContent.trim();
      const credit = parseFloat(cells[1].textContent.trim());
      const levelTerm = cells[2].textContent.trim();
      const sessional = cells[3].textContent.trim().toLowerCase();
      const result = cells[4].textContent.trim();
      const courseType = cells[5].textContent.trim().toLowerCase();

      if (!isNaN(credit) && result && result !== "") {
        rows.push({ courseCode, credit, levelTerm, sessional, result, courseType });
      }
    });

    return rows;
  }

  //Make DataTable show ALL rows
  function showAllRows() {
    return new Promise((resolve) => {
      //Trying jQuery DataTables API first
      if (window.jQuery && window.jQuery.fn.dataTable) {
        const dtApi = window.jQuery("table.dataTable, table.table").DataTable();
        if (dtApi && dtApi.page) {
          dtApi.page.len(-1).draw();
          setTimeout(resolve, 500);
          return;
        }
      }

      //change the select dropdown to show all
      const sel = document.querySelector('select[name$="_length"]');
      if (sel) {
        let allOpt = [...sel.options].find((o) => o.value === "-1");
        if (!allOpt) {
          allOpt = document.createElement("option");
          allOpt.value = "-1";
          allOpt.text = "All";
          sel.appendChild(allOpt);
        }
        sel.value = "-1";
        sel.dispatchEvent(new Event("change", { bubbles: true }));
        setTimeout(resolve, 800);
      } else {
        resolve();
      }
    });
  }

  // ── Restore original page length ──
  function restorePageLength(originalLen) {
    try {
      if (window.jQuery && window.jQuery.fn.dataTable) {
        const dtApi = window.jQuery("table.dataTable, table.table").DataTable();
        if (dtApi && dtApi.page) {
          dtApi.page.len(originalLen).draw();
        }
      }
    } catch (_) {
      /* silent */
    }
  }

  // ── Sort key for Level-Term strings (e.g. "Level 1 - Term I") ──
  function levelTermSortKey(lt) {
    const m = lt.match(/Level\s*(\d+)\s*-?\s*Term\s*(I+|IV|V|\d+)/i);
    if (!m) return 99;
    const level = parseInt(m[1], 10);
    const termStr = m[2].toUpperCase();
    const romanMap = { I: 1, II: 2, III: 3, IV: 4, V: 5 };
    const term = romanMap[termStr] || parseInt(termStr, 10) || 0;
    return level * 10 + term;
  }

  // ── Compute results ──
  function compute(rows) {
    // Group by Level-Term
    const semesters = {};
    rows.forEach((r) => {
      const key = r.levelTerm;
      if (!semesters[key]) semesters[key] = [];
      semesters[key].push(r);
    });

    // Sort keys
    const sortedKeys = Object.keys(semesters).sort(
      (a, b) => levelTermSortKey(a) - levelTermSortKey(b)
    );

    const semesterResults = [];
    let totalWeighted = 0;
    let totalCredits = 0;

    sortedKeys.forEach((key) => {
      const courses = semesters[key];
      let semWeighted = 0;
      let semCredits = 0;

      courses.forEach((c) => {
        const gp = GRADE_MAP[c.result];
        if (gp !== undefined && c.result !== "F") {
          semWeighted += c.credit * gp;
          semCredits += c.credit;
        } else if (c.result === "F") {
          // F counts toward credits attempted but 0 grade points
          semWeighted += 0;
          semCredits += c.credit;
        }
        // else: skip unknown grades (Incomplete, etc.)
      });

      const gpa = semCredits > 0 ? semWeighted / semCredits : 0;
      semesterResults.push({
        name: key,
        courses,
        gpa,
        credits: semCredits,
        earned: semWeighted,
      });

      totalWeighted += semWeighted;
      totalCredits += semCredits;
    });

    const cgpa = totalCredits > 0 ? totalWeighted / totalCredits : 0;

    return { semesterResults, cgpa, totalCredits, totalWeighted };
  }

  // ── Draw performance graph on canvas ──
  function drawGraph(canvas, semesterResults, cgpa) {
    const ctx = canvas.getContext("2d");
    const dpr = window.devicePixelRatio || 1;
    const W = canvas.clientWidth;
    const H = canvas.clientHeight;
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    ctx.scale(dpr, dpr);

    const pad = { top: 30, right: 20, bottom: 40, left: 42 };
    const cw = W - pad.left - pad.right;
    const ch = H - pad.top - pad.bottom;
    const n = semesterResults.length;
    if (n === 0) return;

    // Y axis: 0 – 4.0
    const minY = 0, maxY = 4.0, steps = 4;

    // Grid + labels
    ctx.strokeStyle = "rgba(255,255,255,0.06)";
    ctx.fillStyle = "#64748b";
    ctx.font = "11px Inter,sans-serif";
    ctx.textAlign = "right";
    for (let i = 0; i <= steps; i++) {
      const val = minY + (maxY - minY) * (i / steps);
      const y = pad.top + ch - (i / steps) * ch;
      ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(W - pad.right, y); ctx.stroke();
      ctx.fillText(val.toFixed(1), pad.left - 6, y + 4);
    }

    // X labels
    ctx.textAlign = "center";
    const pts = semesterResults.map((s, i) => {
      const x = pad.left + (n === 1 ? cw / 2 : (i / (n - 1)) * cw);
      const y = pad.top + ch - ((s.gpa - minY) / (maxY - minY)) * ch;
      const label = s.name.replace("Level ", "L").replace(" - Term ", "-T").replace("Term ", "T");
      ctx.fillStyle = "#64748b";
      ctx.fillText(label, x, H - pad.bottom + 18);
      return { x, y, gpa: s.gpa };
    });

    // CGPA reference line
    const cgpaY = pad.top + ch - ((cgpa - minY) / (maxY - minY)) * ch;
    ctx.setLineDash([4, 4]);
    ctx.strokeStyle = "rgba(168,85,247,0.5)";
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(pad.left, cgpaY); ctx.lineTo(W - pad.right, cgpaY); ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = "#a855f7";
    ctx.textAlign = "left";
    ctx.font = "10px Inter,sans-serif";
    ctx.fillText("CGPA " + cgpa.toFixed(2), W - pad.right - 60, cgpaY - 5);

    // Area fill
    const grad = ctx.createLinearGradient(0, pad.top, 0, pad.top + ch);
    grad.addColorStop(0, "rgba(99,102,241,0.25)");
    grad.addColorStop(1, "rgba(99,102,241,0.02)");
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pad.top + ch);
    pts.forEach(p => ctx.lineTo(p.x, p.y));
    ctx.lineTo(pts[pts.length - 1].x, pad.top + ch);
    ctx.closePath();
    ctx.fillStyle = grad;
    ctx.fill();

    // Line
    ctx.beginPath();
    ctx.strokeStyle = "#818cf8";
    ctx.lineWidth = 2.5;
    ctx.lineJoin = "round";
    pts.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
    ctx.stroke();

    // Dots
    pts.forEach(p => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, 5, 0, Math.PI * 2);
      ctx.fillStyle = "#0f172a";
      ctx.fill();
      ctx.beginPath();
      ctx.arc(p.x, p.y, 3.5, 0, Math.PI * 2);
      ctx.fillStyle = "#818cf8";
      ctx.fill();
      ctx.fillStyle = "#e2e8f0";
      ctx.font = "bold 10px Inter,sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(p.gpa.toFixed(2), p.x, p.y - 10);
    });
  }

  // ── Build semester cards HTML ──
  function buildSemCards(semesterResults) {
    return semesterResults.map(sem => {
      let gpaClass = "gpa-low";
      if (sem.gpa >= 3.5) gpaClass = "gpa-excellent";
      else if (sem.gpa >= 3.0) gpaClass = "gpa-good";
      else if (sem.gpa >= 2.5) gpaClass = "gpa-average";
      const rows = sem.courses.map(c => {
        const gp = GRADE_MAP[c.result];
        const gpVal = gp !== undefined ? gp.toFixed(2) : "—";
        return `<tr><td title="${c.courseCode}">${c.courseCode}</td><td>${c.credit.toFixed(2)}</td><td><span class="grade-badge">${c.result}</span></td><td>${gpVal}</td></tr>`;
      }).join("");
      return `<div class="cgpa-sem-card">
        <div class="sem-header" data-semester="${sem.name}">
          <div class="sem-info"><span class="sem-name">${sem.name}</span><span class="sem-credits">${sem.credits.toFixed(1)} cr</span></div>
          <div class="sem-gpa ${gpaClass}">${sem.gpa.toFixed(2)}</div>
          <svg class="sem-chevron" width="16" height="16" viewBox="0 0 16 16"><path d="M4.5 6L8 9.5L11.5 6" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>
        </div>
        <div class="sem-courses hidden"><table><thead><tr><th>Course</th><th>Credit</th><th>Grade</th><th>GP</th></tr></thead><tbody>${rows}</tbody></table></div>
      </div>`;
    }).join("");
  }

  // ── Render the panel ──
  function renderPanel(data) {
    const old = document.getElementById("cuet-cgpa-panel");
    if (old) old.remove();

    const saved = localStorage.getItem("cuet_target_cgpa") || "";

    const panel = document.createElement("div");
    panel.id = "cuet-cgpa-panel";
    panel.innerHTML = `
      <div class="cgpa-header">
        <div class="cgpa-header-top">
          <div class="cgpa-logo">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none"><rect width="24" height="24" rx="6" fill="url(#grad1)"/><defs><linearGradient id="grad1" x1="0" y1="0" x2="24" y2="24"><stop offset="0%" stop-color="#6366f1"/><stop offset="100%" stop-color="#a855f7"/></linearGradient></defs><text x="12" y="17" text-anchor="middle" fill="#fff" font-size="13" font-weight="bold" font-family="Inter,sans-serif">C</text></svg>
            <span>CGPA Calculator</span>
          </div>
          <button id="cgpa-close-btn" title="Close">&times;</button>
        </div>
        <div class="cgpa-overall">
          <div class="cgpa-overall-label">Overall CGPA</div>
          <div class="cgpa-overall-value">${data.cgpa.toFixed(2)}</div>
          <div class="cgpa-overall-sub">${data.totalCredits.toFixed(1)} total credits</div>
        </div>
      </div>
      <div class="cgpa-tabs">
        <button class="cgpa-tab active" data-tab="results">Results</button>
        <button class="cgpa-tab" data-tab="target">Target</button>
        <button class="cgpa-tab" data-tab="graph">Graph</button>
      </div>
      <div class="cgpa-body">
        <div class="cgpa-tab-content active" id="tab-results">${buildSemCards(data.semesterResults)}</div>
        <div class="cgpa-tab-content" id="tab-target">
          <div class="target-section">
            <label class="target-label">Target CGPA</label>
            <input type="number" id="target-cgpa-input" class="target-input" min="0" max="4" step="0.01" placeholder="e.g. 3.50" value="${saved}">
            <label class="target-label" style="margin-top:12px">Remaining Credits</label>
            <input type="number" id="remaining-credits-input" class="target-input" min="0" step="0.5" placeholder="e.g. 60">
            <button id="calc-required-btn" class="target-btn">Calculate Required GPA</button>
            <div id="required-result" class="required-result"></div>
          </div>
        </div>
        <div class="cgpa-tab-content" id="tab-graph">
          <div class="graph-section">
            <div class="graph-title">Semester GPA Trend</div>
            <canvas id="cgpa-graph-canvas" class="cgpa-canvas"></canvas>
          </div>
        </div>
      </div>
      <div class="cgpa-footer"><span>CUET CGPA Calculator Extension</span></div>
    `;
    document.body.appendChild(panel);

    // ── Tab switching ──
    panel.querySelectorAll(".cgpa-tab").forEach(tab => {
      tab.addEventListener("click", () => {
        panel.querySelectorAll(".cgpa-tab").forEach(t => t.classList.remove("active"));
        panel.querySelectorAll(".cgpa-tab-content").forEach(c => c.classList.remove("active"));
        tab.classList.add("active");
        const target = panel.querySelector("#tab-" + tab.dataset.tab);
        target.classList.add("active");
        if (tab.dataset.tab === "graph") {
          setTimeout(() => drawGraph(panel.querySelector("#cgpa-graph-canvas"), data.semesterResults, data.cgpa), 50);
        }
      });
    });

    // ── Close ──
    panel.querySelector("#cgpa-close-btn").addEventListener("click", () => {
      panel.classList.add("cgpa-panel-closing");
      setTimeout(() => panel.remove(), 300);
    });

    // ── Semester expand/collapse ──
    panel.querySelectorAll(".sem-header").forEach(h => {
      h.addEventListener("click", () => {
        h.nextElementSibling.classList.toggle("hidden");
        h.querySelector(".sem-chevron").classList.toggle("rotated");
      });
    });

    // ── Target CGPA calculation ──
    panel.querySelector("#calc-required-btn").addEventListener("click", () => {
      const targetCGPA = parseFloat(panel.querySelector("#target-cgpa-input").value);
      const remCredits = parseFloat(panel.querySelector("#remaining-credits-input").value);
      const box = panel.querySelector("#required-result");

      if (isNaN(targetCGPA) || targetCGPA < 0 || targetCGPA > 4) {
        box.innerHTML = '<div class="req-error">Enter a valid target CGPA (0–4.00)</div>';
        return;
      }
      localStorage.setItem("cuet_target_cgpa", targetCGPA);

      if (targetCGPA <= data.cgpa) {
        box.innerHTML = '<div class="req-success">🎉 You\'ve already achieved this CGPA!</div>';
        return;
      }
      if (isNaN(remCredits) || remCredits <= 0) {
        box.innerHTML = '<div class="req-error">Enter valid remaining credits</div>';
        return;
      }

      const needed = ((targetCGPA * (data.totalCredits + remCredits)) - data.totalWeighted) / remCredits;

      if (needed > 4.0) {
        box.innerHTML = '<div class="req-impossible">❌ Not achievable — requires <strong>' + needed.toFixed(2) + '</strong> GPA (max is 4.00). Try adding more remaining credits.</div>';
      } else if (needed < 0) {
        box.innerHTML = '<div class="req-success">🎉 Already achieved! Any GPA will keep you above target.</div>';
      } else {
        let difficulty = "req-easy";
        let emoji = "✅";
        if (needed >= 3.75) { difficulty = "req-hard"; emoji = "🔥"; }
        else if (needed >= 3.25) { difficulty = "req-medium"; emoji = "💪"; }
        box.innerHTML = '<div class="' + difficulty + '">' + emoji + ' Required GPA: <strong>' + needed.toFixed(2) + '</strong><br><span class="req-sub">You need a <strong>' + needed.toFixed(2) + '</strong> GPA over the next <strong>' + remCredits + '</strong> credits to reach <strong>' + targetCGPA.toFixed(2) + '</strong> CGPA</span></div>';
      }
    });

    // Entrance animation
    requestAnimationFrame(() => panel.classList.add("cgpa-panel-visible"));
  }

  // ── Show a small floating action button ──
  function createFAB() {
    const existing = document.getElementById("cuet-cgpa-fab");
    if (existing) return;

    const fab = document.createElement("button");
    fab.id = "cuet-cgpa-fab";
    fab.title = "Calculate CGPA";
    fab.innerHTML = `
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round">
        <rect x="4" y="2" width="16" height="20" rx="2"/>
        <line x1="8" y1="6" x2="16" y2="6"/>
        <line x1="8" y1="10" x2="16" y2="10"/>
        <line x1="8" y1="14" x2="12" y2="14"/>
        <line x1="8" y1="18" x2="10" y2="18"/>
        <circle cx="15" cy="16" r="2.5" fill="none"/>
      </svg>
    `;

    fab.addEventListener("click", async () => {
      fab.classList.add("fab-loading");
      fab.disabled = true;

      try {
        // Get original page length
        let originalLen = 10;
        try {
          const sel = document.querySelector('select[name$="_length"]');
          if (sel) originalLen = parseInt(sel.value, 10);
        } catch (_) { }

        await showAllRows();
        const rows = getAllRows();

        if (rows.length === 0) {
          alert("No result data found on this page. Please make sure you are on the Published Result page.");
          return;
        }

        const data = compute(rows);
        renderPanel(data);

        // Restore
        restorePageLength(originalLen);
      } catch (err) {
        console.error("CUET CGPA Calculator error:", err);
        alert("Error calculating CGPA. See console for details.");
      } finally {
        fab.classList.remove("fab-loading");
        fab.disabled = false;
      }
    });

    document.body.appendChild(fab);

    // Entrance
    requestAnimationFrame(() => {
      fab.classList.add("fab-visible");
    });
  }

  //Check if result page
  function isResultPage() {
    const title = document.title.toLowerCase();
    const url = window.location.href.toLowerCase();
    const body = document.body ? document.body.textContent.substring(0, 2000).toLowerCase() : "";

    return (
      url.includes("result") ||
      title.includes("result") ||
      body.includes("published result") ||
      body.includes("course code") ||
      document.querySelector("table.dataTable, table.table") !== null
    );
  }

  // Initialize
  function init() {
    setTimeout(() => {
      if (isResultPage()) {
        createFAB();
      }
    }, 1500);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
